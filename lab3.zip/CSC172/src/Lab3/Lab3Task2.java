package Lab3;
//Xuanyu Shen
import java.util.ArrayList;

public class Lab3Task2 {
	public static void main(String[] args){
        int[][] array1 = {{10, 15, 30, 40},{15, 5, 8, 2}, {20, 2, 4, 2},{1, 4, 5, 0}};
        ArrayList<ArrayList<Integer>> list1= new ArrayList<>(4);
        for(int i=0;i<4;i++){
            list1.add(new ArrayList<Integer>());
            for(int j=0;j<array1[i].length;j++){
                list1.get(i).add(array1[i][j]);
	}
        }
        array1 = runningSum2DArray(array1,2);
        Lab3Task1.print2Darray(array1);
        Lab3Task1.print2Darray(runningSum2DArray(array1,1));
        list1 = runningSum2DArrayList(list1,4);
        Lab3Task1.print2DList(list1);
        Lab3Task1.print2DList(runningSum2DArrayList(list1,3));
    }
        public static int[][] runningSum2DArray(int[][] array, int dir){//left to right
            int[][] result = array;
            if(dir == 1){
                for(int i=0;i<array.length;i++) {
                    for(int j=1;j<array[i].length;j++) {
                        result[i][j]=array[i][j-1]+array[i][j];
                    }
                }
            }else if(dir == 2){//right to left
                for(int i=0;i<array.length;i++) {
                    for(int j=array.length-2;j>=0;j--) {
                        result[i][j]=array[i][j+1]+array[i][j];
                    }
                }
            }else if(dir == 3) {//up to bottom
                for(int i=0;i<array[0].length;i++) {
                    for(int j=1;j<array[i].length;j++) {
                        result[j][i]=array[j-1][i]+array[j][i];
                    }
                }
            }else if(dir ==4){//bottom to up
                for(int i=0;i<array[0].length;i++) {
                    for(int j=array.length-2;j>=0;j--) {
                        result[j][i]=array[j+1][i]+array[j][i];
                    }
                }
            }
            return result;
        }

        public static ArrayList<ArrayList<Integer>> runningSum2DArrayList(ArrayList<ArrayList<Integer>> list, int dir){
            ArrayList<ArrayList<Integer>> result = list;
            if(dir == 1){//left to right
                for(int i=0;i<list.size();i++) {
                    for(int j=1;j<list.get(i).size();j++) {
                        result.get(i).set(j,list.get(i).get(j)+list.get(i).get(j-1));
                    }
                }
            }else if(dir == 2){//right to left
                for(int i=0;i<list.size();i++) {
                    for(int j=list.get(i).size()-2;j>=0;j--) {
                        result.get(i).set(j,list.get(i).get(j)+list.get(i).get(j+1));
                    }
                }

            }else if(dir == 3) {//up to bottom
                for(int i=0;i<list.size();i++) {
                    for(int j=1;j<list.get(i).size();j++) {
                        result.get(j).set(i,list.get(j).get(i)+list.get(j-1).get(i));
                    }
                }
            }else if(dir ==4){//bottom to up
                for(int i=0;i<list.size();i++) {
                    for(int j=list.get(i).size()-2;j>=0;j--) {
                        result.get(j).set(i,list.get(j).get(i)+list.get(j+1).get(i));
                    }
                }
            }
            return result;
        }
	}

