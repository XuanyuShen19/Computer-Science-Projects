package Lab3;
//Xuanyu Shen

import java.util.ArrayList;
import java.util.Iterator;

public class Lab3Task3 {
	public static void main(String[] args){

        ArrayList<Integer> al= new ArrayList<>();
        al.add(1);
        al.add(5);
        al.add(7);
        al.add(2);
		printArrayListBasicLoop(al);
		printArrayListEnhancedLoop(al);
		printArrayListForLoopListIterator(al);
	}
	
	public static void printArrayListBasicLoop(ArrayList<Integer> al) {//for loop
		for (int i = 0; i < al.size(); i++){
            int element = al.get(i);
            System.out.println(element);
        }
	}
	
	
	public static void printArrayListEnhancedLoop(ArrayList<Integer> al) {//enhanced for loop
		for (int element: al) {
			System.out.println(element);
		}
	}
	
	public static void printArrayListForLoopListIterator(ArrayList<Integer> al) {
		for(Iterator<Integer> iterator= al.iterator(); iterator.hasNext();){// basic for loop with iterator
            System.out.println(iterator.next());
        }
	}
	
	public static void printArrayListWhileLoopListIterator(ArrayList<Integer> al) {// Iterator with while loop
		Iterator<Integer> iterator = al.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
		
	
	}
}
		
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

