package Lab3;//Xuanyu Shen
import java.util.ArrayList;
public class Lab3Task1 {
    public static void main(String[] args){
	        int[][] array = {{10, 15, 30, 40},{15, 5, 8, 2}, {20, 2, 4, 2},{1, 4, 5, 0}};
	        print2Darray(array);
	        ArrayList<ArrayList<Integer>> al = new ArrayList<>(4);
	        for(int i=0; i < 4; i++){
	            al.add(new ArrayList<>());
	        }
	        for(int i=0; i <4;i++){
	            for(int j=0; j<4;j++){
	                int number = array[i][j];
	                al.get(i).add(number);
	            }
	        }
	        print2DList(al);
	    }

	    public static void print2Darray(int[][] array){
	        for(int i=0; i<array.length;i++){
	            for(int element: array[i]){
	                System.out.print(element);
	                System.out.print("\t");
	            }
	            System.out.println("");
	        }
	    }

	    public static void print2DList(ArrayList<ArrayList<Integer>> list){
	        for(int i=0;i<list.size();i++){
	            for(int j=0;j<list.get(i).size();j++){
	                System.out.print(list.get(i).get(j));
	                System.out.print("\t");
	            }
	            System.out.println("");
	        }
	    }
	}


