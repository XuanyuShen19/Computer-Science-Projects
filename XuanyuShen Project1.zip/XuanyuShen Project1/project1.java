/*Name: Xuanyu Shen 
  NetID: xshen20 
  assignment number: HW2
  lab section: Tue/Thur 9:40-10:55
  I didn't collaborate with anyone on this assignment
 */
import java.util.Scanner;
public class project1
{
  public static void main (String[] args)
  {
    System.out.println("Welcome to the game of TTY Projectiles");//instructions
    System.out.println("In this game, you have a catapult that can launch projectiles. In each round of the game, the computer places a wall in front of you. You aim their catapult by setting the launch angle and speed. The computer then computes whether the projectile makes it over the wall and informs you. The user gets points for clearing the wall and loses points for hitting the wall.  The game continues through successive rounds until you quit.");
    System.out.println("In this game, the maximum height of the wall is 10, the maximum distance is 10, close clear + 5,far clear + 3, close miss -2, far miss -4, no costs each trial. Good Luck!"); //game point policy                   
    
    int score;
    for(score = 0;score < score+1;score = 0 + score){   //score accumulating through a for loop                  
    double wall = Math.random()* 10;//wall hight settings
    if (wall >= 0 && wall <= 3)//give hints previously
     System.out.println("the wall is not high");
      else if (wall > 3 && wall <= 7)
       System.out.println("the wall is medium high"); 
        else if (wall > 7 && wall <= 10)
         System.out.println("the wall is very high");
                       
    double d = Math.random()* 10;//distance(from the wall) settings
     if (wall >= 0 && wall <= 3)//give hints previously
      System.out.println("the distance is not far away");
       else if (wall > 3 && wall <= 7)
        System.out.println("the distance is medium far"); 
         else if (wall > 7 && wall <= 10)
          System.out.println("the distance is very far");                   
                                              
    System.out.println("please enter the the speed");//enter speed
    Scanner num1 = new Scanner(System.in);
    int speed = num1.nextInt();
    System.out.println("please enter the the angle");//enter angle                   
    Scanner num2 = new Scanner(System.in);
    int angle = num2.nextInt();
                       
    double h = d*Math.tan((180/Math.PI)*angle)-(9.8*d*d)/(2*(speed*Math.cos((180/Math.PI)*angle))*(speed*Math.cos((180/Math.PI)*angle)));// calculate the hight the player makes 
    
                       
    if (h > 1.2*wall)//if the actuall hight is higher than 1.2Wall, then it is far clear,if the height is lower than 1.2Wall,but higher than Wall, it is close clear
     {System.out.println("far clear, nice!");//we use 0.2Wall as a boundary unit
      score = score + 3;// get 3 points for far clear
    }
     else if ( h > wall && h <= 1.2*wall)
      {System.out.println("close clear,excellent!");
       score = score + 5;
     }
      else if ( h < 0.8*wall)
      {System.out.println("far miss");
       score = score - 4;
      }
       else if ( h >= 0.8*wall && h <= wall)
      {System.out.println("close miss");
       score = score - 2;
      } 
       System.out.println("you score right now is " + score);
       
       System.out.println("Do you want to quit? (1 for yes, 2 for no)");//quit part 1 for quit,2 for not quit
       Scanner num3 = new Scanner(System.in);
       int choice = num3.nextInt();
       if (choice == 1)
       {System.out.println("BYE BYE!");
         break;
       }
       else if (choice == 2)
         continue;
    }
                       }
}
          
                       
       
       
   
