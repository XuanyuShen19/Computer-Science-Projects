Name: Xuanyu Shen
NetID: xshen20
Assignment number: HW6
Lab section: Tuesday/Thursday 9:40-10:55


I did this project by myself. All the information are in the program.

