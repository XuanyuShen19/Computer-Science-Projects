//Xuanyu Shen
package Project1;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class InfixCalculator {
    public static void main(String args[]) throws IOException {

        File file = new File(args[0]);
        ArrayList<Double> resultset = new ArrayList<Double>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "GBK"));
            BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
            String s = null;

            while ((s = br.readLine()) != null) {
                NewQueue postfix = ShuntingYard.toPostfix(s);
                double result = postfixEvaluation.postfixEvaluation(postfix);
                resultset.add(result);
                System.out.println(result);
                bw.write(String.valueOf(result));
                bw.newLine();
            }
            br.close();
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
