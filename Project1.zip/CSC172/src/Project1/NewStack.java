package Project1;//Xuanyu Shen


public class NewStack<E> implements Stack<E>{
    LinkedList stack;

    //Bellow is the constructor of this class.
    public NewStack(){
        stack = new LinkedList<E>();
    }

    //The method bellow will return true if the stack has nothing inside; false otherwise.
    public boolean isEmpty() {
        return stack.isEmpty();
    }

    //The method bellow will insert the given object to the top of the stack.
    public void push(E x) {
        stack.addFirst(x);
    }

    //The method bellow will return and remove the object on the top of the stack.
    public E pop() {
        return (E) stack.remove(0);
    }

    //The method will return the object on the top of the stack without removing it.
    public E peek() {
        return (E) stack.get(0);
    }
}
