package Project1;//Xuanyu Shen

public class postfixEvaluation {
    public static double postfixEvaluation(NewQueue postfix){
        double result = -1;
        NewStack stack = new NewStack();
        while(!postfix.isEmpty()){
            if(postfix.peek() instanceof Double){
                stack.push(postfix.dequeue());
            }else if(postfix.peek() instanceof String){
                double r;
                if(postfix.peek().equals("!")){
                    double v1 = (double) stack.pop();
                    r = calculate((String)postfix.dequeue(),v1);
                }else {
                    double v1 = (double) stack.pop();
                    double v2 = (double) stack.pop();
                    r = calculate((String)postfix.dequeue(),v1,v2);
                }
                stack.push(r);
            }
        }
        if(!stack.isEmpty()){
            result = (double) stack.pop();
        }
        return result;
    }

    public static double calculate(String sign,double value2, double value1){
        double result = -1;
        if(sign.equals("+")){
            result = value1 + value2;
        }else if(sign.equals("-")){
            result = value1 - value2;
        }else if(sign.equals("*")){
            result = value1 * value2;
        }else if(sign.equals("/")){
            result = value1 / value2;
        }else if(sign.equals("^")){
            result = 1;
            if(value2>0){
                for(int i=0;i<value2;i++){
                    result *= value1;
                }
            }else if(value2==0){
                result = 1;
            }else if(value2<0){
                for(int i=0;i<value2;i++){
                    result *= value1;
                }
                result = 1 / result;
            }
        }else if(sign.equals("%")){
            int n = (int) (value1 / value2);
            result = value1 - (n * value2);
        }else if(sign.equals(">")){
            if(value1 > value2){
                result = 1;
            }else{
                result = 0;
            }
        }else if(sign.equals("<")){
            if(value1 < value2){
                result = 1;
            }else{
                result = 0;
            }
        }else if(sign.equals("=")){
            if(value1 == value2){
                result = 1;
            }else{
                result = 0;
            }
        }else if(sign.equals("&")){
            if((value1==1.0 || value1==0.0) && (value2==1.0 || value2==0.0)){
                if(value1==1.0 && value2==1.0){
                    result = 1;
                }else{
                    result = 0;
                }
            }else{
                result = -1;
            }
        }else if(sign.equals("|")){
            if((value1==1.0 || value1==0.0) && (value2==1.0 || value2==0.0)){
                if(value1==0.0 && value2==0.0){
                    result = 0;
                }else{
                    result = 1;
                }
            }else{
                result = -1;
            }
        }
        return result;
    }
    public static double calculate(String sign,double value1){
        double result = -1;
        if(sign.equals("cos")){
            return (Math.cos(value1));
        }else if(sign.equals("sin")){
            return (Math.sin(value1));
        }else if(sign.equals("tan")){
            return (Math.tan(value1));
        }
        if(value1 == 1.0){
            result = 0;
        }else if(value1 == 0.0){
            result = 1;
        }
        return result;
    }
}
