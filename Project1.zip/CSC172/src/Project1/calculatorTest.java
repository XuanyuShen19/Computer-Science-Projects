package Project1;//Xuanyu Shen
public class calculatorTest {
    public static void main(String args[]){
        String str = "3.0 * 4";
        String infix[] = str.split(" ");
        infix = ShuntingYard.splitParentheses(infix);
        infix = ShuntingYard.removeSpaces(infix);
        for(int i=0;i<infix.length;i++){
            System.out.print(infix[i]+" ");
        }
        System.out.println("");
                //"1 - 2 ^ 3 ^ 3 - ( 4 + 5 * 6) * 7";
        NewQueue postfix = ShuntingYard.toPostfix(str);
        while(postfix.isEmpty()==false){
            System.out.print(postfix.dequeue()+" ");
        }

    }
}
