package Project1;
//Contact Information: qtang5@u.rochester.edu
//Lab Period: CSC172 TR16:50-18:05
//Partner: Shengyi Jia
import java.util.ArrayList;

public class ShuntingYard {
    public static NewQueue toPostfix(String line){
        String number = "1234567890.";
        String operator = "+-**/()^%sincostan><=&|!";
        String logicOperator = "< > = & | !";
        String[] infix;
        ArrayList<String> list = new ArrayList<>();
        line += " ";
        String element = "";
        for(int i=0;i<line.length();i++){
            if(number.contains(line.substring(i,i+1))) {
                element += line.substring(i, i + 1);
            }
            else if("cossintan".contains(line.substring(i,i+1))){
                if(element.length()>0){
                    list.add(element);
                    element="";
                }
                element += line.substring(i,i+1);
            }
            else if(operator.contains(line.substring(i,i+1))){
                if(element.length()>0){
                    list.add(element);
                    element = "";
                }
                list.add(line.substring(i,i+1));
            }
            if(line.substring(i,i+1).equals(" ")){
                if(element.length()>0){
                    list.add(element);
                    element = "";
                }
            }
        }

        infix = new String[list.size()];
        for(int i=0;i<list.size();i++){
            infix[i] = list.get(i);
        }
        NewQueue postfix = new NewQueue();
        NewStack operatorList = new NewStack();

        for(int i=0;i<infix.length;i++){
            String token = infix[i];
            if(token.length()!=0 && number.contains(token)) {
                postfix.enqueue(Double.parseDouble(token));
            }else if(token.length()>1 && number.contains(token.substring(0,1))){
                postfix.enqueue(Double.parseDouble(token));
            }else if(token.equals(")")) {
                while (!operatorList.isEmpty()) {
                    if (operatorList.peek().equals("(")) {
                        operatorList.pop();
                        break;
                    }
                    postfix.enqueue(operatorList.pop());
                }
            }else if(token!=null && operator.contains(token)){
                if(operatorList.isEmpty() || token.equals("(")){
                    operatorList.push(token);
                }else {
                    int level=checkLevel((String) operatorList.peek());;
                    int tokenLevel = checkLevel(token);
                    int nextLevel = 4;
                    if(tokenLevel<level) {
                        while (!operatorList.isEmpty()) {
                            level = checkLevel((String) operatorList.peek());
                            postfix.enqueue(operatorList.pop());
                            if(operatorList.isEmpty()){
                                break;
                            }
                            if(!operatorList.isEmpty()){
                                nextLevel = checkLevel((String) operatorList.peek());
                            }
                            if (operatorList.peek().equals("(")) {
                                break;
                            }else if(nextLevel<level){
                                postfix.enqueue(operatorList.pop());
                                break;
                            }
                        }
                    }
                    operatorList.push(token);
                }
            }
        }
        while(!operatorList.isEmpty()){
            postfix.enqueue(operatorList.pop());
        }
        return postfix;
    }

    public static int checkLevel(String str){
        String operator1 = "+-";
        String multiple = "*";
        String divide = "/";
        String mod = "%";
        String operator3 = "^";
        String operator4 = "(";
        String less = "<";
        String larger = ">";
        String equals = "=";
        String not = "!";
        String and = "&";
        String or = "|";
        String cos = "cos";
        String sin = "sin";
        String tan = "tan";
        int n = 1;
        if(multiple.contains(str) || divide.contains(str) || mod.contains(str) || cos.contains(str)||sin.contains(str)||tan.contains(str)){
            n = 2;
        }else if(operator3.contains(str)){
            n = 3;
        }else if(operator4.contains(str)){
            n = 0;
        }else if(operator1.contains(str)){
            n = 1;
        }else if(less.contains(str) || larger.contains(str) || equals.contains(str) || not.contains(str) || and.contains(str) || or.contains(str)){
            n = 0;
        }
        return n;
    }

    public static int findHighest(NewStack stack){
        ArrayList<String> list = new ArrayList();
        int highest = 1;
        int n;
        while(stack.isEmpty()==false){
            list.add((String) stack.pop());
        }
        for(int i=list.size()-1;i>=0;i--){
            stack.push(list.get(i));
        }
        for(int i=0;i<list.size();i++){
            n = checkLevel(list.get(i));
            if(n>highest){
                highest = n;
            }
        }
        return highest;
    }

    public static String[] removeSpaces(String[] str){
        int size = str.length;
        String[] str1;
        for(int i=0;i<str.length;i++){
            if(str[i].equals(" ")||str[i].equals("")){
                size--;
                for(int j=i;j<str.length-1;j++){
                    str[j] = str[j+1];
                }
            }
        }
        str1= new String[size];
        for(int i=0;i<str1.length;i++){
            str1[i] = str[i];
        }
        str = str1;
        return str;
    }

    public static String[] mergeDot(String[] str){
        for(int i=0;i<str.length;i++){
            int left = 0;
            int right = 0;

            if(str[i].equals(".")){
                left = i;
                right = i;
                for(int j=i-1;j>=0;j--){
                    if("0123456789".contains(str[j])){
                        left--;
                    }else if(str[j].length()>1 && "0123456789".contains(str[j].substring(0,1))){
                        left--;
                    }else{
                        break;
                    }
                }
                for(int j=i+1;j<str.length;j++){
                    if("0123456789".contains(str[j])){
                        right++;
                    }else if(str[j].length()>1 && "0123456789".contains(str[j].substring(0,1))){
                        right++;
                    }else {
                        break;
                    }
                }
            }

            for(int j = left+1;j<=right;j++){
                str[left] += str[j];
                str[j] = "";
            }
        }
        return removeSpaces(str);
    }

    public static String[] splitParentheses(String[] str){
        ArrayList<String> list = new ArrayList<>();
        for(int i=0;i<str.length;i++){
            while(str[i].contains("(")) {
                list.add(str[i].substring(0, 1));
                str[i] = str[i].substring(1);
            }
            while(str[i].contains(")")){
                int index = str[i].indexOf(")");
                if(index==0){
                    String[] s = str[i].split("");
                    for(int j=0;j<s.length;j++) {
                        list.add(s[j]);
                    }
                    break;
                }else {
                    list.add(str[i].substring(0, index));
                    list.add(str[i].substring(index, index + 1));
                    str[i] = str[i].substring(index + 1);
                }
            }
            if(!str[i].contains("(") && !str[i].contains(")")){
                list.add(str[i]);
            }
        }
        str = new String[list.size()];
        for(int i=0;i<list.size();i++){
            str[i] = list.get(i);
        }
        return str;
    }
}
