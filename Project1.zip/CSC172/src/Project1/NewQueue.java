package Project1;//Xuanyu Shen


public class NewQueue<E> implements Queue {
    LinkedList queue;
    int size;
    //Bellow is the constructor of this class.
    public NewQueue(){
        queue = new LinkedList();
        size = 0;
    }

    //The method bellow will return true if the queue has nothing inside; false otherwise.
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    //The method bellow will insert the given object into the queue
    public void enqueue(Object x) {
        queue.addLast(x);
        size++;
    }

    //The method bellow will return and remove the first object added to the queue.
    public E dequeue() {
        return (E) queue.remove(0);
    }

    //The method bellow will return the first object added to the queue without removing it.
    public Object peek() {
        return (E) queue.get(0);
    }
}
