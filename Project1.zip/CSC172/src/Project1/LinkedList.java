package Project1;//Xuanyu Shen

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedList<E> implements List<E>{
    int size = 0;
    Node<E> first;
    Node<E> last;
    public LinkedList(){
    }

    public LinkedList(Collection<? extends E> c){
        this();
        addAll(c);
    }

    public void addFirst(E e){
        Node<E> f = first;
        Node<E> newLink = new Node<E>(e,null,f);
        first=newLink;
        if(f==null){
            last=newLink;
        }else{
            f.setPrev(newLink);
        }
        size++;
    }

    public void addLast(E e){
        Node<E> l = last;
        Node<E> newLink = new Node<E>(e,l,null);
        last = newLink;
        if(l==null){
            first=newLink;
        }else{
            l.setNext(newLink);
        }
        size++;
    }

    public E peekFirst(){
        Node<E> f = first;
        if(f==null){
            return null;//Return null if the list is null;
        }else{
            return f.element();//Return the first element being peeked.
        }
    }

    public E peekLast(){
        Node<E> l = last;
        if(l==null){
            return null;//Return null if the list is null;
        }else{
            return l.element();//Return the last element being peeked.
        }
    }

    public E pollFirst(){
        Node<E> f = first;
        if(f==null){
            return null;//Return null if the list is null;
        }else{
            first = first.next();
            size--;
            return f.element();//Return the first element being peeked.
        }
    }

    public E pollLast(){
        Node<E> l = last;
        if(l==null){
            return null;//Return null if the list is null;
        }else{
            last = last.prev();
            size--;
            return l.element();//Return the last element being peeked.
        }
    }

    public boolean add(E o) {
        addLast(o);
        return true;//Return true when o is added to the list.
    }

    public void add(int index, E element) {
        if(index<0||index>=size){
            throw new IndexOutOfBoundsException();
        }
        if(index == size-1){
            addLast(element);
        }else if(index == 0){
            addFirst(element);
        }
        Node<E> node1;
        Node<E> node2;
        node1 = first;
        for(int i=0;i<index;i++){
            node1 = node1.next();
        }
        node2 = node1.next();
        Node<E> newNode = new Node<E>(element,node1,node2);
        node1.setNext(newNode);
        node2.setPrev(newNode);
        size++;
    }

    public boolean addAll(Collection c) {
        for(Object e: c){
            addLast((E) e);
        }
        return true;//Return true when all elements in c ared added to the list.
    }

    public boolean addAll(int index, Collection c) {
        for(Object e: c){
            add(index,(E) e);
            index++;
        }
        return true;//Return true when all elements in c ared added to the list.
    }

    public void clear() {
        for (Node<E> i = first; i != null; ) {
            Node<E> next = i.next();
            i.setElement(null);
            i.setNext(null);
            i.setPrev(null);
            i = next;
        }
        first = last = null;
        size = 0;
    }

    public boolean contains(Object o) {
        for(Node<E> i=first;i!=null;){
            Node<E> next = i.next();
            if(i.element()!=null && i.element().equals(o)){
                return true;//Return true if the object is contained in the list.
            }
            i = next;
        }
        return false;//Return false if the object is not contained in the list.
    }

    public E get(int index) {
        if(index>=size || index<0){
            throw new IndexOutOfBoundsException();
        }
        if(index == 0){
            return (first.element());//Return the first element of list if the index is 0;
        }else if(index == size-1){
            return (last.element());//Return the last element of list if the index is the index of the last element;
        }
        int count = 0;
        for(Node<E> i=first;i!=null;){
            Node<E> next = i.next();
            if(count == index){
                return i.element();//Return the element on the specified index.
            }
            i = next;
            count++;
        }
        return null;//Return null if the element on index is null or cannot be found.
    }

    public int indexOf(Object o) {
        int index=0;
        for(Node<E> i=first;i!=null;){
            Node<E> next = i.next();
            if(i.element()!=null && i.element().equals(o)){
                return index;//Return the index where the object first appears in the list;
            }
            i = next;
            index++;
        }
        return -1;//Return -1 if object does not appear in the list.
    }

    public boolean isEmpty() {
        if(first==null) {
            return true;//
        }
        return false;
    }

    @Override
    public Iterator iterator() {
        return new Iterator() {
            int index = 0;
            public boolean hasNext() {
                return index!=size();
            }

            public Object next() {
                index++;
                if(index>size){
                    throw new NoSuchElementException();
                }
                return get(index);
            }
        };
    }

    public E remove(int index) {
        if(index<0 || index>=size){
            throw new IndexOutOfBoundsException();
        }
        int count = 0;
        Node<E> removal=null;
        for(Node<E> i=first;i!=null;){
            Node<E> next = i.next();
            removal = i;
            if(count == index){
                break;
            }
            i = next;
            count++;
        }
        if(count == 0){
            first = removal.next();
            return removal.element();
        }else if(count == size){
            last = removal.prev();
            return removal.element();
        }
        removal.prev().setNext(removal.next());
        removal.next().setPrev(removal.prev());
        size--;
        return removal.element();
    }

    public boolean remove(Object o) {
        int index = 0;
        if(contains(o)){
            index = indexOf(o);
            remove(index);
            return true;
        }else{
            return false;//Return false as the object is not in the list.
        }
    }


    public Object set(int index, Object element) {
        if(index<0 || index>size){
            throw new IndexOutOfBoundsException();
        }
        int count = 0;
        for(Node<E> i = first;i!=null;){
            if(count==index){
                i.setElement((E)element);
            }
            i = i.next();
            count++;
        }
        return element;//Return the element being set to the specified index.
    }


    public int size() {
        return size;//Return the size of the list;
    }

    public List subList(int fromIndex, int toIndex) {
        if(fromIndex<0 || fromIndex>size-1 || toIndex<0||toIndex>=size-1){
            throw new IndexOutOfBoundsException();
        }
        LinkedList sublist = new LinkedList();
        for(int i=fromIndex;i<=toIndex;i++){
            sublist.add(get(i));
        }
        return sublist;//Return the sublist of the original list from "fromIdex" position to "toIndex" position.
    }

    public Object[] toArray() {
        Object[] array = new Object[size];
        int index = 0;
        for(Node<E> i =first;i!=null;){
            array[index] = i.element();
            index++;
        }
        return array;//Return the array form of the list.
    }

    public boolean removeAll(Collection c) {
        int count1 = 0;
        int count2 = 0;
        for (Object e : c) {
            count1++;
            if (contains(e) == false) {
                count2++;
            }
        }
        if(count1==count2){
            return false;//Return false if the list contains none of the elements in the collection.
        }
        for(Object e: c){
            if(contains(e)){
                remove(e);
            }
        }
        return true;//Return true if all elements in the list that are also in the collection are removed.
    }

    public boolean containsAll(Collection c) {
        for(Object e:c){
            if(contains(e) == false){
                return false;//Return false if the list does not contain all elements.
            }
        }
        return true;//Return true if the list contains all elements.
    }
}
