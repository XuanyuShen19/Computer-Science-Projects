/*	Name: Xuanyu Shen
	Email: xshen20@u.rochester.edu
*/
import javax.swing.JPanel; 
import java.awt.Graphics; 
import java.awt.Graphics2D; 
import java.awt.Color; 
import java.awt.event.KeyEvent; 
import java.awt.event.KeyListener; 
import java.util.HashMap;
import java.util.ArrayList;
import java.awt.*;

//draw graphs
public class Canvas extends JPanel {

  HashMap<String, Node> nodeMap;
  HashMap<String, Edge> edgeMap;
  ArrayList<Edge> mst;
  ArrayList<Node> sp;
  private double minLat;
  private double minLong;
  private double maxLat;
  private double maxLong;
  private double yUnit;
  private double xUnit;
  private int selection;

  protected void paintComponent(Graphics g){ 
	    super.paintComponent(g);
	    Graphics2D g2d = (Graphics2D) g.create();
	    g2d.setStroke(new BasicStroke(1));
	    xUnit = getWidth()/(maxLong - minLong);
	    yUnit = getHeight()/(maxLat - minLat);
	    //O(E)
	    edgePainter(g2d); 
	    //O(V)
	    if(selection < 0){
	      shortPath(g2d);
	    }
	    //O(E)
	    else{
	      minWeight(g2d); 
	    }
	  }

  public Canvas(HashMap<String, Node> nM, HashMap<String, Edge> eM, ArrayList<Edge> m, ArrayList<Node> s, int selection){
    setFocusable(true);
    nodeMap = nM;
    edgeMap = eM;
    double[] extreme = extrema();
    minLat = extreme[0];
    maxLat = extreme[1];
    minLong = extreme[2];
    maxLong = extreme[3];
    mst = m;
    sp = s;
    this.selection = selection;
  }

  public void edgePainter(Graphics2D g2d){
	//O(E)
    for (Edge e : edgeMap.values()){
      Node a = nodeMap.get(e.w);
      Node b = nodeMap.get(e.v);
      int x1 = (int) ((getHeight() - Math.abs(a.lat - Math.abs(minLat)) * yUnit));
      int y1 = (int) (((a.lon * xUnit)) - minLong * xUnit);
      int x2 = (int) ((getHeight() - Math.abs(b.lat - Math.abs(minLat)) * yUnit));
      int y2 = (int) (((b.lon * xUnit)) - minLong * xUnit);
      g2d.drawLine(y1,x1, y2,x2);
    }
  }

  public void minWeight(Graphics2D g2d){
    g2d.setStroke(new BasicStroke(2));
    g2d.setColor(Color.RED);
    //O(E)
    for (Edge e : mst){ 
      Node a = nodeMap.get(e.w);
      Node b = nodeMap.get(e.v);
      int x1 = (int) ((getHeight() - Math.abs(a.lat - Math.abs(minLat)) * yUnit));
      int y1 = (int) (((a.lon * xUnit)) - minLong * xUnit);
      int x2 = (int) ((getHeight() - Math.abs(b.lat - Math.abs(minLat)) * yUnit));
      int y2 = (int) (((b.lon * xUnit)) - minLong * xUnit);
      g2d.drawLine(y1,x1, y2,x2);
    }
  }

  public double[] extrema(){
    double[] ex = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
    for (Node n : nodeMap.values()){
      if (n.lat < ex[0]){
        ex[0]=n.lat;
      }
      if (n.lat > ex[1]){
        ex[1]=n.lat;
      }
      if (n.lon < ex[2]){
        ex[2]=n.lon;
      }
      if (n.lon > ex[3]){
        ex[3]=n.lon;
      }
    }
    return ex;
  }
  
  public void shortPath(Graphics2D g2d){
    g2d.setStroke(new BasicStroke(2));
    g2d.setColor(Color.BLUE);
    Node a = sp.get(0);
    //O(V)
    for (int i = 1; i < sp.size(); i++){ 
      Node b = sp.get(i);
      int x1 = (int) ((getHeight() - Math.abs(a.lat - Math.abs(minLat)) * yUnit));
      int y1 = (int) (((a.lon * xUnit)) - minLong * xUnit);
      int x2 = (int) ((getHeight() - Math.abs(b.lat - Math.abs(minLat)) * yUnit));
      int y2 = (int) (((b.lon * xUnit)) - minLong * xUnit);
      g2d.drawLine(y1,x1, y2,x2);
      a = b;
    }
  }

}