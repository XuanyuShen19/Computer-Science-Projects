/*	Name: Xuanyu Shen
	Email: xshen20@u.rochester.edu
*/

//store the data and the pointer
public class MyNode<AnyType> {
  public AnyType data; 
  public MyNode<AnyType> next; 
}