/*	Name: Xuanyu Shen
	Email: xshen20@u.rochester.edu
*/
public class SetNode {
  String id;
  SetNode l;
  public SetNode(String i){
    id = i;
  }

  public void union (SetNode x){
    l = x;
  }

  public boolean equals(SetNode b){
    return (id.equals(b.id));
  }
}