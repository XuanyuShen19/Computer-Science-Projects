/*	Name: Xuanyu Shen
	Email: xshen20@u.rochester.edu
*/

public class GraphNode implements Comparable<GraphNode>{
  GraphNode next;
  double weight;
  int cons;
  String parent;
  String road;
  String id;

  public GraphNode(String i){
    id = i;
    cons = 0;
  }

  public void insert(GraphNode n, String a, Double lb, String par, String r){
    if(n.next == null){
      n.next = new GraphNode(a);
      n.next.weight = lb;
      n.next.parent = par;
      n.next.road = r;
      cons++;
    }
    else{
      insert(n.next, a, lb, par, r);
    }
  }

  public boolean lookup(GraphNode n, String a){
    if(n == null){
      return false;
    }
    else if (n.id.equals(a)){
      return true;
    }
    else{
      return lookup(n.next, a);
    }
  }

  public double lookupWeight(GraphNode n, String a){
    if(n == null){//can not happen
      return 10000000; //maximum of the integer in java.
    }
    else if (n.id.equals(a)){
      return n.weight;
    }
    else{
      return lookupWeight(n.next, a);
    }
  }

  public void printConnections(){
    if (next == null){
      return;
    }
    else {
      System.out.print(next.id +", ");
      next.printConnections();
    }
  }
  public GraphNode[] getConnections(){
    GraphNode[] ans = new GraphNode[cons];
    Con(this,ans, 0);
    return ans;
  }

  public GraphNode[] Con(GraphNode n, GraphNode[] a, int p){
    if (n.next == null){
      return a;
    }
    else{
      a[p] = n.next;
      return Con(n.next, a, p+1);
    }
  }

  public boolean equals (String x){
    return (x.equals(id));
  }

  public int compareTo(GraphNode that){
    if (this.weight == that.weight){
      return 0;
    }
    else if (this.weight > that.weight){
      return 1;
    }
    else{
      return -1;
    }
  }
}