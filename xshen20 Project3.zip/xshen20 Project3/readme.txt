Name: Xuanyu Shen
Email: xshen20@u.rochester.edu
Lab section: Monday/Wednesday 6:15-7:30pm
Introduction:
Follow the steps from the mission and spend a lot of time on create a map and setting Nodes. 
All Files include:
SetNode.java
Node.java
MyNode.java
Mapping.java
Edge.java
Canvas.java
Atlas.java
OUTPUT
readme
txt map files
Run steps: will be shown on OUTPUT file.