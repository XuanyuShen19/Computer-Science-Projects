Name: Xuanyu Shen
NetID: xshen20
Assignment number: Project 4
Lab section: Tuesday/Thursday 9:40-10:55

I did this alone.

Guide: 
The game has several components and rules.
1. the maximum speed for the speed slider is 100. The maximum angle for angle slider is 90 degree.
2. New game refresh the game, that means the position of the target, the score, the round will be zero out.
3. distance is include in the state part, once you run the game, you can see numbers next the state, that is the distance.

Game rule:
1. The target doesn't move until you hit the target, because I think if every round we change the position of the target, it's hard for the player to earn points. 
But you can click on "New Game" to refresh the game.(I really spend a lot of time to improve the project to do so, I hope I can earn some extra credits, thank you!)
2.When you hit the target, the word "Hit" comes out.(Extra Credit)
3. The start point is the mouth of the face.
4.The score rule: Every time you cost 1 point to gain a round, that's automatically included in the system. When you hit the target, score + 5, if it is "near miss" ,
score + 1, if it is "fell short" score -1, if it is "went far", score - 2. (if we include the cost every time, it is +4,+0,-2,-3)

