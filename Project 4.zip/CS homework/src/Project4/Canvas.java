package Project4;
/*Name: Xuanyu Shen
NetID: xshen20
Assignment number: Project 3
Lab section: Tuesday/Thursday 9:40-10:55
I didn't collaborate with any other students on this assignment
*/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.Timer;



public class Canvas extends JComponent implements ActionListener{
	int num;
	int x = 0;//start point for the line (x,y)
	int y = getHeight();
	
	int x1;// end point for the line
	int y1;
	
	int v;// speed for line 1 
	int a;// angle for line 1
	int t;// time 
	
	Timer timer;
	JButton button;//"OK" button
	JButton button2;//"New Game" Button
	JSlider j1;//speed
	JSlider j2;//angle
	JSlider j3 = new JSlider(JSlider.VERTICAL, 0, 100, 0);
	JSlider j4 = new JSlider(JSlider.VERTICAL, 0, 90, 0);
	JLabel label1,label2,label3,label4,label5;
	JTextField field1;
	JTextField field2;
	JTextField field3;
	JTextField field4;
	JTextField field5;
	JLabel label9;
	JLabel label6;
	JLabel label7;
	JLabel label8;
	JLabel label10;
	JTextField field6;
	JTextField field7;
	JTextField field9;
	JTextField field10;
	int score = 0;
	int time = 0;
	int round = 1;
	double t0 = 0;
	int c = (int) (Math.random()*400);
	int d;
	boolean launch1=false;
	
	public Canvas() {
		
		setLayout(new FlowLayout());
		label1 = new JLabel("speed" );//0-100
		add(label1);
		j1 = new JSlider(JSlider.VERTICAL, 0, 100, 0);
		add(j1); 
		
	    label2 = new JLabel("angle" );//0-90 degree
		add(label2);
		j2 = new JSlider(JSlider.VERTICAL, 0, 90, 0);
		add(j2);
		button = new JButton("OK");//set the "OK" button
		button.addActionListener(this);
		
		add(button);
		button2 = new JButton("New Game");//set the "New Game" button
		button2.addActionListener(this);
		add(button2);
		label6 = new JLabel("State" );//outcome and distance 
		add(label6);
		label3 = new JLabel("null" );
		add(label3);
		label7 = new JLabel("Score" );//score part
		add(label7);
		label4 = new JLabel("0" );
		add(label4);
		label8 = new JLabel("Round" );//round 
		add(label8);
		label5 = new JLabel("1" );//start with round 1
		add(label5);
		timer = new Timer(50, new TimerCallback());//animate
		
	}
		    

	
	
	
	public void paintComponent(Graphics g) {
		 x = 300;
 	     y = 500;
 	     x1 = 300;//end point (x1,y1)
 	     y1 = 500;
 	    v = j1.getValue();//get velocity and speed
        a = j2.getValue();
        
        g.drawOval(x-40,y-30,50,50);
        g.drawString("x", x-10, y-10);
        g.setColor(Color.RED);
	    g.fillRect(x,y-2,10,5);
	    
        
 	    if(launch1) {
 	    	timer.start();// when we click on "OK",timer starts
 	    	x = (int) (300+v*t0*(int)(100*Math.cos(a*(Math.PI)/180))/100);//start point (x,y)
 	 	    y = (int) (500-v*(t0)*(int) (100*Math.sin(a*(Math.PI)/180))/100+(int)((0.5*9.81*(t0)*(t0)*100))/100);
 	 	    x1 = (int) (300+v*(t0+1)*(int)(100*Math.cos(a*(Math.PI)/180))/100);//end point (x1,y1)
 	 	    y1 = (int) (500-v*(t0+1)*(int) (100*Math.sin(a*(Math.PI)/180))/100+(int)((0.5*9.81*(t0+1)*(t0+1)*100))/100);
 	 	    g.drawLine(x, y,x1,y1); 
 	    }
 	    
 	    if (y>800) {
 	    	timer.stop();//if the "line" goes down too much, we let the line go back to the origin.
 	    	launch1=false;
 	    	t0 = 0;
 	    }
 	     
 	     g.setColor(Color.gray);//the "target"
	   	 g.fillOval(300+c,500-15,20,20);
 	     d = (int)(1000*v*v*Math.sin(2*a*(Math.PI)/180)/9.81)/1000;
 	     
 	     if (d <= c+32 && d >= c+2 && y > 600 ) {//if we hit the target, we go to the next random target
 	    	c = (int) (Math.random()*400); 
 	     }
 	     
	   	 g.setColor(Color.blue);
	   	 g.drawLine(300, 500, 900, 500);//the ground line 
	   	 
	   	if (d <= c+32 && d >= c+2  ) {//extra credit: display "hit" when we hit the target
	   	 if(y >=500 || y <= 700) {
	   	g.setFont(new Font("TimesRoman", Font.BOLD, 20)); 
    	g.drawString("Hit!", c+300, 500);
	   	 }
	   	}
	}
	
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();// to receive command when you click on the button
		Graphics g = getGraphics();
		super.paint(g);
		 
	 	 
		if(e.getSource()== button) {
			launch1=true;
			repaint();
		}

	        
	         
	    	if (d <= c+32 && d >= c+2 ) {// some estimation error and I adjusted it a little, every 30 unite is a range
	        	label3.setText("direct hit "+" "+"distance"+ Integer.toString(d) );//*I automatically minus 1 for the chance cost
	    	                                                        //the number that displayed is the distance
	        	    System.out.println("direct hit");//direct hit score + 5
	        	    score = score + 4;
	        	    label4.setText(Integer.toString(score));
	        	    round = round + 1;
	        	    label5.setText(Integer.toString(round));
	        	   
	        	    System.out.println(score);
	        	}
	          else if (d > c+32 && d <= c+ 62 || d< c+2 && d >= c-28) {// near miss + 1
	        	  label3.setText("near miss "+" "+"distance"+ Integer.toString(d) );
	    		   
	                  System.out.println("near miss");
	                  score = score + 0;
	                  label4.setText(Integer.toString(score));
	                  round = round + 1;
		        	    label5.setText(Integer.toString(round));
	                  System.out.println(score);
	           } 
	            else if (d > c + 62 && d <= c+ 92|| d< c-28 && d >= c-58) {//fell short -1
	            	label3.setText("fell short "+" "+" " + "distance"+ Integer.toString(d) );
	    		     
	                   System.out.println("fell short");
	                   score = score - 2;
	                   label4.setText(Integer.toString(score));
	                   round = round + 1;
		        	   label5.setText(Integer.toString(round));
	                   System.out.println(score);
	             }
	            else {
	            	label3.setText("went long"+" "+ "distance"+ Integer.toString(d) );//went long -3
	    		     
	            	     System.out.println("went long");
	            	     score = score - 4;
	            	     label4.setText(Integer.toString(score));
	            	     round = round + 1;
			        	 label5.setText(Integer.toString(round));
	            	     System.out.println(score);
	            }
	    	
	    	
	    
	    if (cmd.equals("New Game")) {//new game resets the score, round, and target
	    	score = 0;
	    	round = 1;
	    	label4.setText(Integer.toString(score));
	    	label5.setText(Integer.toString(round));
	    	c = (int) (Math.random()*400); 
	    }
	    
	    
	    
	    
	    }
	  
	    
	class TimerCallback implements ActionListener{//timecallback class
		@Override 
		public void actionPerformed(ActionEvent e) {
			t0+=0.3;
			repaint(); 
			}
		}

 
	
	
public static void main(String[] args) {
    
	JFrame frame = new JFrame();
	Canvas Animation = new Canvas();
	frame.add(Animation);  
	frame.setSize(800,600);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	frame.setVisible(true);
	
	}
}