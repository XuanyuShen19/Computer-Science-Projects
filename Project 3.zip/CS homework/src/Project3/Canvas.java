package Project3;
/*Name: Xuanyu Shen
NetID: xshen20
Assignment number: Project 3
Lab section: Tuesday/Thursday 9:40-10:55
I didn't collaborate with any other students on this assignment
*/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;






public class Canvas extends JFrame implements ActionListener{
	int x = 0;//start point for line 1 (x,y)
	int y = 0;
	int x2 = 0;//start point for line 2
	int y2 = 0;
	int x1;// end point for line 1
	int y1;
	int x3;// end point for line 3
	int y3;
	int v;// speed for line 1 
	int a;// angle for line 1
	int t;// time for both line 1 and line 2
	int c;// color for line 1
	int type;// type for line 1
	int v2;// same for line 2
	int a2;
	int t2;
	int c2;
	int type2;
	JButton button;
	JLabel label1;
	JLabel label2;
	JLabel label3;
	JLabel label4;
	JLabel label5;
	JTextField field1;
	JTextField field2;
	JTextField field3;
	JTextField field4;
	JTextField field5;
	
	JLabel label6;
	JLabel label7;
	JLabel label9;
	JLabel label10;
	JTextField field6;
	JTextField field7;
	JTextField field9;
	JTextField field10;
	
	public Canvas() {
		setSize(800,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setLayout(new FlowLayout());
		label1 = new JLabel("speed" );
		add(label1);
		field1 = new JTextField(10);//set the text field (maximum 10 digital number)
	    add(field1);
	    label2 = new JLabel("angle" );
		add(label2);
	    field2 = new JTextField(10);
	    add(field2);
	    label3 = new JLabel("time(explode at 6)" );
		add(label3);
	    field3 = new JTextField(10);
	    add(field3);
	    label4 = new JLabel("color(red yellow blue for '1' '2' '3')" );
		add(label4);
	    field4 = new JTextField(10);
	    add(field4);
	    label5 = new JLabel("explode type(1-5)" );
		add(label5);
	    field5 = new JTextField(10);
	    add(field5);
	    label6 = new JLabel("speed2" );
		add(label6);
		field6 = new JTextField(10);
	    add(field6);
	    label7 = new JLabel("angle2" );
		add(label7);
	    field7 = new JTextField(10);
	    add(field7);
	    label9 = new JLabel("color2(red yellow blue for '1' '2' '3')" );
		add(label9);
	    field9 = new JTextField(10);
	    add(field9);
	    label10 = new JLabel("explode type2(1-5)" );
		add(label10);
	    field10 = new JTextField(10);//set the text field (maximum 10 digital number)
	    add(field10);
		button = new JButton("OK");//set the button
		button.addActionListener(this);
		add(button);
		
	        
	}
	
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();// to receive command when you click on the button
	    if (cmd.equals("OK")) {
	        v = Integer.parseInt(field1.getText());
	        a = Integer.parseInt(field2.getText());
	        t = Integer.parseInt(field3.getText());
	        c = Integer.parseInt(field4.getText());
	        type = Integer.parseInt(field5.getText());
	        v2 = Integer.parseInt(field6.getText());
	        a2 = Integer.parseInt(field7.getText());
	        c2 = Integer.parseInt(field9.getText());
	        type2 = Integer.parseInt(field10.getText());
	    }
		
	  
	    
	      
	for (int t0 = 0;t0 < t; t0++) {	//I use lines to collect the start and end points after each loop
		Graphics g = getGraphics();
		 x = 300+v*t0*(int)(100*Math.cos(a*(Math.PI)/180))/100;//start point (x,y)
	     y = 300-v*(t0)*(int) (100*Math.sin(a*(Math.PI)/180))/100+(int)((0.5*9.81*(t0)*(t0)*100))/100;
	     x1 = 300+v*(t0+1)*(int)(100*Math.cos(a*(Math.PI)/180))/100;//end point (x1,y1)
	     y1 = 300-v*(t0+1)*(int) (100*Math.sin(a*(Math.PI)/180))/100+(int)((0.5*9.81*(t0+1)*(t0+1)*100))/100;
	     switch(c) {//using "Switch" to set color
		    case 1:
		      g.setColor(Color.red);
		      break;
		    case 2:
		    	g.setColor(Color.yellow);
		      break;
		    case 3:
		    	g.setColor(Color.blue);
		      break;
		    default:
		        g.setColor(Color.black);
		      break;
		  }
	     
	     g.drawLine(x, y,x1,y1);
	     
	     
	     x2 = 600-v2*t0*(int)(100*Math.cos(a2*(Math.PI)/180))/100;//start point (x,y)
	     y2 = 300-v2*(t0)*(int) (100*Math.sin(a2*(Math.PI)/180))/100+(int)((0.5*9.81*(t0)*(t0)*100))/100;
	     x3 = 600-v2*(t0+1)*(int)(100*Math.cos(a2*(Math.PI)/180))/100;//end point (x1,y1)
	     y3 = 300-v2*(t0+1)*(int) (100*Math.sin(a2*(Math.PI)/180))/100+(int)((0.5*9.81*(t0+1)*(t0+1)*100))/100;
	     switch(c2) {//using "Switch" to set color
		    case 1:
		      g.setColor(Color.red);
		      break;
		    case 2:
		    	g.setColor(Color.yellow);
		      break;
		    case 3:
		    	g.setColor(Color.blue);
		      break;
		    default:
		        g.setColor(Color.black);
		      break;
		  }
	     
	     g.drawLine(x2,y2,x3,y3);// collect those points
	   
	     if (x == x2 && y == y2 ) {
    	 g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); // if they hit each other, "Hit!" comes out
    	 g.drawString("Hit!", x1, y1);
	     break;   
     }
	     
	     else if (t0==5) {//when time is 6, we explodes, since t = t0 + 1
	     switch(type) {//using "Switch" to set the explode type
	     case 1://explode with a face
	       g.drawOval(x1,y1,50,50);
	       g.drawString("x", x1+10, y1+20);
	       g.drawString("x", x1+35, y1+20);
	       g.drawLine(x1+15, y1+40, x1+35, y1+40);
	       break;
	     case 2:
	    	 for(int i=0;i<50;i++){//explode with random "x"
	    	 int n=(int)(Math.random()*50);
	    	 int m=(int)(Math.random()*50);
	    	 g.drawString("x",x+n,y+m);
	    	 }
	       break;
	     case 3:
	    	 for(int i=0;i<50;i++){//explode with random rectangular
		    	 int n=(int)(Math.random()*50);
		    	 int m=(int)(Math.random()*50);
		    	 g.drawRect(x+n,y+m, 5, 10);
		    	 }
	    	 break;
	     case 4:
	    	 for(int i=0;i<50;i++){//explode with random ovals
		    	 int n=(int)(Math.random()*50);
		    	 int m=(int)(Math.random()*50);
		    	 g.drawOval(x+n,y+m, 5, 5);
		    	 }
	    	 break;
	     default:
	    	 g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); // explode with word "BOOM"
	    	 g.drawString("BOOM!", x1, y1);
		     break;  
	   }
	     
	     switch(type2) {//using "Switch" to set the explode type
	     case 1://explode with a face
	       g.drawOval(x3,y3,50,50);
	       g.drawString("x", x3+10, y3+20);
	       g.drawString("x", x3+35, y3+20);
	       g.drawLine(x3+15, y3+40, x3+35, y3+40);
	       break;
	     case 2:
	    	 for(int i=0;i<50;i++){//explode with random "x"
	    	 int n=(int)(Math.random()*50);
	    	 int m=(int)(Math.random()*50);
	    	 g.drawString("x",x2+n,y2+m);
	    	 }
	       break;
	     case 3:
	    	 for(int i=0;i<50;i++){//explode with random rectangular
		    	 int n=(int)(Math.random()*50);
		    	 int m=(int)(Math.random()*50);
		    	 g.drawRect(x2+n,y2+m, 5, 10);
		    	 }
	    	 break;
	     case 4:
	    	 for(int i=0;i<50;i++){//explode with random ovals
		    	 int n=(int)(Math.random()*50);
		    	 int m=(int)(Math.random()*50);
		    	 g.drawOval(x2+n,y2+m, 5, 5);
		    	 }
	    	 break;
	     default:
	    	 g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); // explode with word "BOOM"
	    	 g.drawString("BOOM!", x3, y3);
		     break;  
	   }
	     break;
	     }
	     }
	     
	
	
	 if (x>getWidth()) {//make the canvas flexible to extend
	 		x = getWidth();
	 	}
	     if (y>getHeight()) {
		 		y = getHeight();
		 	}
	}
	
	
	public void paint(Graphics g) {//make the simulation appear when we pull the window(copy the content above)
		super.paint(g);
		for (int t0 = 0;t0 < t; t0++) {	//I use lines to collect the start and end points after each loop
			
			 x = 300+v*t0*(int)(100*Math.cos(a*(Math.PI)/180))/100;//start point (x,y)
		     y = 300-v*(t0)*(int) (100*Math.sin(a*(Math.PI)/180))/100+(int)((0.5*9.81*(t0)*(t0)*100))/100;
		     x1 = 300+v*(t0+1)*(int)(100*Math.cos(a*(Math.PI)/180))/100;//end point (x1,y1)
		     y1 = 300-v*(t0+1)*(int) (100*Math.sin(a*(Math.PI)/180))/100+(int)((0.5*9.81*(t0+1)*(t0+1)*100))/100;
		     switch(c) {//using "Switch" to set color
			    case 1:
			      g.setColor(Color.red);
			      break;
			    case 2:
			    	g.setColor(Color.yellow);
			      break;
			    case 3:
			    	g.setColor(Color.blue);
			      break;
			    default:
			        g.setColor(Color.black);
			      break;
			  }
		     
		     g.drawLine(x, y,x1,y1);
		     
		     
		     x2 = 600-v2*t0*(int)(100*Math.cos(a2*(Math.PI)/180))/100;//start point (x,y)
		     y2 = 300-v2*(t0)*(int) (100*Math.sin(a2*(Math.PI)/180))/100+(int)((0.5*9.81*(t0)*(t0)*100))/100;
		     x3 = 600-v2*(t0+1)*(int)(100*Math.cos(a2*(Math.PI)/180))/100;//end point (x1,y1)
		     y3 = 300-v2*(t0+1)*(int) (100*Math.sin(a2*(Math.PI)/180))/100+(int)((0.5*9.81*(t0+1)*(t0+1)*100))/100;
		     switch(c2) {//using "Switch" to set color
			    case 1:
			      g.setColor(Color.red);
			      break;
			    case 2:
			    	g.setColor(Color.yellow);
			      break;
			    case 3:
			    	g.setColor(Color.blue);
			      break;
			    default:
			        g.setColor(Color.black);
			      break;
			  }
		     
		     g.drawLine(x2, y2,x3,y3);
		   
		     if (x == x2 && y == y2 ) {
	    	 g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); // explode with word "BOOM"
	    	 g.drawString("Hit!", x1, y1);
		     break;   
	     }
		     
		     else if (t0==5) {//when time is 6, we explodes, since t = t0 + 1
		     switch(type) {//using "Switch" to set the explode type
		     case 1://explode with a face
		       g.drawOval(x1,y1,50,50);
		       g.drawString("x", x1+10, y1+20);
		       g.drawString("x", x1+35, y1+20);
		       g.drawLine(x1+15, y1+40, x1+35, y1+40);
		       break;
		     case 2:
		    	 for(int i=0;i<50;i++){//explode with random "x"
		    	 int n=(int)(Math.random()*50);
		    	 int m=(int)(Math.random()*50);
		    	 g.drawString("x",x+n,y+m);
		    	 }
		       break;
		     case 3:
		    	 for(int i=0;i<50;i++){//explode with random rectangular
			    	 int n=(int)(Math.random()*50);
			    	 int m=(int)(Math.random()*50);
			    	 g.drawRect(x+n,y+m, 5, 10);
			    	 }
		    	 break;
		     case 4:
		    	 for(int i=0;i<50;i++){//explode with random ovals
			    	 int n=(int)(Math.random()*50);
			    	 int m=(int)(Math.random()*50);
			    	 g.drawOval(x+n,y+m, 5, 5);
			    	 }
		    	 break;
		     default:
		    	 g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); // explode with word "BOOM"
		    	 g.drawString("BOOM!", x1, y1);
			     break;  
		   }
		     
		     switch(type2) {//using "Switch" to set the explode type
		     case 1://explode with a face
		       g.drawOval(x3,y3,50,50);
		       g.drawString("x", x3+10, y3+20);
		       g.drawString("x", x3+35, y3+20);
		       g.drawLine(x3+15, y3+40, x3+35, y3+40);
		       break;
		     case 2:
		    	 for(int i=0;i<50;i++){//explode with random "x"
		    	 int n=(int)(Math.random()*50);
		    	 int m=(int)(Math.random()*50);
		    	 g.drawString("x",x2+n,y2+m);
		    	 }
		       break;
		     case 3:
		    	 for(int i=0;i<50;i++){//explode with random rectangular
			    	 int n=(int)(Math.random()*50);
			    	 int m=(int)(Math.random()*50);
			    	 g.drawRect(x2+n,y2+m, 5, 10);
			    	 }
		    	 break;
		     case 4:
		    	 for(int i=0;i<50;i++){//explode with random ovals
			    	 int n=(int)(Math.random()*50);
			    	 int m=(int)(Math.random()*50);
			    	 g.drawOval(x2+n,y2+m, 5, 5);
			    	 }
		    	 break;
		     default:
		    	 g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); // explode with word "BOOM"
		    	 g.drawString("BOOM!", x3, y3);
			     break;  
		   }
		     break;
		     }
		}
	}
	
	public static void main(String[] args) {
		
		new Canvas().setVisible(true);   //set the canvas visible
		
			
	}
	
}
