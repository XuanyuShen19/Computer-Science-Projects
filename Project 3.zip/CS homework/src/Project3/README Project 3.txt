Name: Xuanyu Shen
NetID: xshen20
Assignment number: Project 
Lab section: Tuesday/Thursday 9:40-10:55


Guide: 
I did extra credit 1, so I have two firework simulations.
when you run this program, it will appear 9 text fields. I've already labeled them. The start point of line 1 is (300,300),line 2 is (600,300). Speed and Angle(in degree) is for the first fire work, Speed2 and Angle 2(in degree)
is for the second firework. Their lauch time are the same, so there is only one text field for the time, noticing that these two fire work will explode both at time 6.
Color and Color 2 is for the two lines' color setting, explode type is actually 1-4, and type 5 is the default one, same as Color.


