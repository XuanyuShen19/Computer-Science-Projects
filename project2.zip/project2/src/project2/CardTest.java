package project2;
public class CardTest {

	public static void main(String[] args) {//call those methods
		
		Deck Cardlist = new Deck();
		System.out.println("Problem 1");
		Cardlist.cardList();
		Cardlist.rankChange();
	    Cardlist.shuffle();
	    System.out.println(" ");
	    System.out.println(" ");
	    System.out.println("Problem 2");
	    Cardlist.generateCard();
	    System.out.println(" ");
	    System.out.println(" ");
	    System.out.println("Problem 3");
	    Cardlist.Classification();
	    Compare run = new Compare();

	    run.compare();
}
}
