package project2;
import java.util.Random;
public class Deck extends Card {
	 
	Card[] arr; //initialize arr and its type is Card(So that we can input values into suits and ranks)
	
	public Deck() {
		
		arr = new Card[52];
	}
	
	public void cardList() {
		
	    
		rank = 1; 
		for(int i = 0 ; i < 13;i++) {//position 0 - 12 for suit diamond
			arr[i]=new Card();
			arr[i].setSuit("Diamond");
			
			arr[i].setRank(rank=rank+1);	 	
		}
		
	
	
	    rank =1;
		for(int i = 13; i < 26;i++) {//position 13- 25 for suit heart
			 
			arr[i]=new Card();
	    	arr[i].setSuit("hearts");
		    	arr[i].setRank(rank = rank+1);
		    	
		    	}
	
		rank = 1;
		for(int i = 26; i < 39;i++) {//position 26-38 for suit club
			arr[i]=new Card(); 
	    	arr[i].setSuit("clubs");
		    arr[i].setRank(rank=rank+1);
		   
		    	
		    	}	
		
	
	
		rank = 1;
		for(int i = 39; i < 52;i++) {//position 39-51 for suit spade
			arr[i]=new Card(); 
	    	arr[i].setSuit("Spades");
		    arr[i].setRank(rank=rank+1);
		    	}	
	    	
		
		
		for(Card x: arr)//print out those cards in order
		{
			if (x.rank > 10) {
				x.rankChange();
				System.out.print(x.getSuit()+" "+x.getRank1()+" ");//we don't print out rank but rank 1 for J Q K A
			}
			else
				System.out.print(x.getSuit()+" "+x.getRank()+" ");
		}
	}
	
	public void shuffle() {//using swap to exchange values of random positions 
		System.out.println(" ");
		System.out.println("Shuffle the cards ");
		Random rand = new Random();
		for (int i=0; i<52; i++) {
			int num = rand.nextInt(51);
		    Card temp = arr[i];
		    arr[i] = arr[num];
		    arr[num] = temp;    
	}
		for(Card x: arr)//print them out
		{
			if (x.rank > 10) {
				x.rankChange();
				System.out.print(x.getSuit()+" "+x.getRank1()+" ");
			}
			else
				System.out.print(x.getSuit()+" "+x.getRank()+" ");
		}	
	}
	
	
	public void generateCard() {
	
		
		System.out.println("The first person's cards are ");//first person's card is from position 0 to 5(of course
		                                                    //random selected)
		for (int i=0; i<5; i++) {
			
		    if (arr[i].rank > 10) {
				arr[i].rankChange();
				System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");//print them out
			}
			else
				System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
	}
	
		
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("The second person's cards are ");//second person's cards are from 5 to 10
		for (int i=5; i<10; i++) {
		    if (arr[i].rank > 10) {
				arr[i].rankChange();
				System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");
			}
			else
				System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
	}
		
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("The remaining cards are ");// the remaining cards are all the cards behind these two's cards
		for (int i=10; i< 52; i++) {
			if (arr[i].rank > 10) {
				arr[i].rankChange();
				System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");
			}
			else
				System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
		}
	}	
		
	public void Classification() {	
		//player 1 order rank
		 
		System.out.println("player1 in order");
		
		
		boolean fixed = false;// rank player 1's card in order, from smallest to largest
		while(fixed == false) {
		fixed = true;
	    for (int i = 0; i < 4; i++)
	    {
	        if(arr[i].rank > arr[i+1].rank)
	        {
	            Card temp=arr[i+1];
	            arr[i+1]=arr[i];
	            arr[i]=temp;
	            fixed = false;
	        }	    
		}
		}
		for (int i = 0; i < 5; i++) {
	    if (arr[i].rank > 10) {
			arr[i].rankChange();
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");
		}
		else
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
		}
		
		//player 2 in order
		System.out.println(" ");
		System.out.println("player2 in order");
		
		
		boolean fixed2 = false;
		while(fixed2 == false) {
		fixed2 = true;
	    for (int i = 5; i < 9; i++)
	    {
	        if(arr[i].rank > arr[i+1].rank)
	        {
	            Card temp=arr[i+1];
	            arr[i+1]=arr[i];
	            arr[i]=temp;
	            fixed2 = false;
	        }	    
		}
		}
		for (int i = 5; i < 10; i++) {
	    if (arr[i].rank > 10) {
			arr[i].rankChange();
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");//print them out to check
		}
		else
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
		}
		
		//player 1 pair judge(for 2 pairs and 1 pair)
		int pair = 0;
		int index = 0;
		for(int i=0; i<4; i++) {
			if (arr[i].getRank()==arr[i+1].getRank())
			{
				pair=pair + 1;
			}
			if (arr[i].getRank()!=arr[i+1].getRank())
			{
				index=index+1;//index is for locate the largest card in hands, though it's hard to tell, you'll see it later
			}
			
		}
		
		//player 2 pair judge
		int pair1 = 0;
		int index1 = 5;
		for(int i=5; i<9; i++) {
			if (arr[i].getRank()==arr[i+1].getRank())
			{
				pair1=pair1 + 1;
			}
			if (arr[i].getRank()!=arr[i+1].getRank())
			{
				index1=index1+1;
			}
		    
		}
		
		
		  
		System.out.println(" ");	
		
	int level;// level is for "who wins" part, it's easy to compare if we set a value to compare
	
	//player 1's card classification
	if (arr[0].getSuit()==arr[1].getSuit()&&//just list all the probabilities out
			arr[1].getSuit()==arr[2].getSuit()&&
			arr[2].getSuit()==arr[3].getSuit()&&
			arr[3].getSuit()==arr[4].getSuit()&&
			arr[0].getRank()==arr[1].getRank()+1&&
			arr[1].getRank()==arr[2].getRank()+1&&
			arr[2].getRank()==arr[3].getRank()+1&&
			arr[3].getRank()==arr[4].getRank()+1
			
			
			
			)
		{System.out.println("player1 has a straight flush");
		level=9;
		}
	else if (arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank()||
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank())
	{System.out.println("player1 has a four of kind");
	level=8;
	}
	else if (arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()&&
			arr[3].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[3].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[4].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[1].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()&&
			arr[1].getRank()==arr[3].getRank()||
			arr[0].getRank()==arr[3].getRank()&&
			arr[4].getRank()==arr[3].getRank()&&
			arr[1].getRank()==arr[2].getRank()||
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[0].getRank()==arr[4].getRank()||
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()&&
			arr[0].getRank()==arr[3].getRank()||
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank()&&
			arr[0].getRank()==arr[1].getRank()
			)
	{System.out.println("player1 has a full house");
	level=7;
	}
	else if (arr[0].getSuit()==arr[1].getSuit()&&
			arr[1].getSuit()==arr[2].getSuit()&&
			arr[2].getSuit()==arr[3].getSuit()&&
			arr[3].getSuit()==arr[4].getSuit())
	{System.out.println("player1 has a flush");
	level=6;
	}
			
	else if (arr[0].getRank()==arr[1].getRank()+1&&
			arr[1].getRank()==arr[2].getRank()+1&&
			arr[2].getRank()==arr[3].getRank()+1&&
			arr[3].getRank()==arr[4].getRank()+1)
	{System.out.println("player1 has a straight");
	level=5;
	}	
		
	else if (arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()||
			
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[3].getRank()||
			
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[4].getRank()||
			
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
			
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			
			arr[0].getRank()==arr[3].getRank()&&
			arr[4].getRank()==arr[3].getRank()||
			
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
		
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank())
	{System.out.println("player1 has a three of a kind");
	level=4;
	}	
		
	else if (pair == 2){//this pair is the pair we have from the loop above somewhere
				System.out.println("player1 has a 2 pairs");
				level=3;
			}
	else if (pair == 1){
		System.out.println("player1 has a pair");
		level=2;
	}
	else {
		System.out.println("player1 has only high cards");
		level = 1;//high cards
	}
	
	
	//player 2 card's classification(same way)
	int level1;
	if (arr[5].getSuit()==arr[6].getSuit()&&
			arr[6].getSuit()==arr[7].getSuit()&&
			arr[7].getSuit()==arr[8].getSuit()&&
			arr[8].getSuit()==arr[9].getSuit()&&
			arr[5].getRank()==arr[6].getRank()+1&&
			arr[6].getRank()==arr[7].getRank()+1&&
			arr[7].getRank()==arr[8].getRank()+1&&
			arr[8].getRank()==arr[9].getRank()+1)
		{System.out.println("player2 has a straight flush");
		level1=9;
		}
	else if (arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank()||
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank())
	{System.out.println("player2 has a four of kind");
	level1=8;
	}
	else if (arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()&&
			arr[8].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[8].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[9].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[6].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()&&
			arr[6].getRank()==arr[8].getRank()||
			arr[5].getRank()==arr[8].getRank()&&
			arr[9].getRank()==arr[8].getRank()&&
			arr[6].getRank()==arr[7].getRank()||
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[5].getRank()==arr[9].getRank()||
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()&&
			arr[5].getRank()==arr[8].getRank()||
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank()&&
			arr[5].getRank()==arr[6].getRank()
			)
	{System.out.println("player2 has a full house");
	level1=7;
	}
	else if (arr[5].getSuit()==arr[6].getSuit()&&
			arr[6].getSuit()==arr[7].getSuit()&&
			arr[7].getSuit()==arr[8].getSuit()&&
			arr[8].getSuit()==arr[9].getSuit())
	{System.out.println("player2 has a flush");
	level1=6;
	}
			
	else if (arr[5].getRank()==arr[6].getRank()+1&&
			arr[6].getRank()==arr[7].getRank()+1&&
			arr[7].getRank()==arr[8].getRank()+1&&
			arr[8].getRank()==arr[9].getRank()+1)
	{System.out.println("player2 has a straight");
	level1=5;
	}	
		
	else if (arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()||
			
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[8].getRank()||
			
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[9].getRank()||
			
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
			
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			
			arr[5].getRank()==arr[8].getRank()&&
			arr[9].getRank()==arr[8].getRank()||
			
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
		
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank())
	{System.out.println("player2 has a three of a kind");
	level1=4;
	}	
		
	else if (pair1 == 2){
				System.out.println("player2 has a 2 pairs");
				level1=3;
			}
	else if (pair1 == 1){
		System.out.println("player2 has a pair");
		level1=2;
	}
	else {
		System.out.println("player2 has only high cards");
		level1 = 1;//high cards
	}	
			
			
			
			
	// "who wins" part		 
	if (level1>level) {
		System.out.println("player2 wins");
	}
	else if (level1<level) {
		System.out.println("player1 wins");
	}
	else if (level1==level&&level==9) {//level 9 since we ranked all the cards, thus the last one is the biggest one
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	else if (level1==level&&level==8) {//level 8
		if (arr[2].rank>arr[7].rank) {
			System.out.println("Player1 wins");//I used some unique method. It's hard tell. 
			}
			else if (arr[2].rank<arr[7].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[2].rank==arr[7].rank){
				if (arr[4].rank<arr[9].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[9].rank>arr[4].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
	}
	
	else if (level1==level&&level==7) {//level 7
		if (arr[2].rank>arr[7].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[2].rank<arr[7].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[2].rank==arr[7].rank){
				if (arr[3].rank<arr[8].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[3].rank>arr[8].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
				}
	
	else if (level1==level&&level==6) {//level 6 compare the largest rank
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	
	else if (level1==level&&level==5) {//level 5 compare the largest rank
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	
	else if (level1==level&&level==4) {//level 4 
		if (arr[2].rank>arr[7].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[2].rank<arr[7].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[2].rank==arr[7].rank){
				if (arr[3].rank<arr[8].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[3].rank>arr[8].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
				}
	
	
	else if (level1==level&&level==3) {//level 3
		if (arr[3].rank>arr[8].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[3].rank<arr[8].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[3].rank==arr[8].rank){
				if (arr[4].rank<arr[9].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[4].rank>arr[9].rank) {
					System.out.println("Player1 wins");
				}
				else if (arr[4].rank==arr[9].rank){
					if(arr[0].rank>arr[5].rank) {
						System.out.println("Player1 wins");	
					}
					else if(arr[0].rank<arr[5].rank) {
						System.out.println("Player2 wins");	
					}
					else if(arr[0].rank==arr[5].rank) {
						System.out.println("no winner");	
					}
				}
				}
				}
	
	else if (level1==level&&level==2) {//level 2
		if (arr[index].rank>arr[index1].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[index].rank<arr[index1].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[index].rank==arr[index1].rank){
				if (arr[4].rank<arr[9].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[4].rank>arr[9].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
				}
	
	else if (level1==level&&level==1) {//level 1 compare the largest rank
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	}
	
	
	
	
	
	
	
	
	
	}			

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	

