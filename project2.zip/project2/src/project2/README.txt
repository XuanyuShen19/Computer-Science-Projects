Name: Xuanyu Shen
NetID: xshen20
Assignment number: Project 2
Lab section: Tuesday/Thursday 9:40-10:55
I did it by myself

Probelm1: I created a Card class and the type "Card" contains rank and suit, I use rank1 to replace rank when rank is greater than 10, because I need to print out 
String type,but the value is still unchanged, just for print it out. I actually created a method in Card class to do this. Then I use 4 loops, each for 1 suit, and set the
values of ranks and suits. For the shuffle one, I created a method in deck called shuffle. I used swap to reandomly swap two array members.

Problem2: I use the first ten cards (after shuffle) as the two player's hands, and use loops to print them out and the remaining cards are just the cards remaining 
after selecting out the 10 cards.  

Problem 3: I first rank the two player's cards from smallest to the largest, since it is easier for us to do later classification. Classification: I use if ...else if... else if.... 
to list all the classifications. From Straight Flush to Three of a kind, I list all the conditions which are constant to those classifications. For two pairs and one pair, I 
first use a loop to count pairs in one players card and find the index of the biggest pair card(which will be used later to justify the winner). Then I just pick up the 
value of pair and write them into if statement, if pair equals 1 , then it is a one pair, if it is two, it is a two pairs.

For "who wins" part, I use a lot of "if" statements and the basic logic is to find player 1's probability-overlapped, biggest card's position and then compare to player
 2's. And if they are the same, compare the rightest one(biggest one).

Problem 4: I randomly typed 2 hands, then use "split" to split the one array into 10 strings. Every string is given a value of a card type array space,using a if 
statements, also ,every 2 String will make the pisition "i" to increase by 1. Then, I copied all the classification content into the Compare class to run the compare part.