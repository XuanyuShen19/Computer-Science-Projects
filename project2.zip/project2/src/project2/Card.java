package project2;

public class Card {
	   String suit;
	   int rank;
	   String rank1;//this rank1 is for print out J Q K A
	 
	


	public String getSuit() {//getters and setters
		return suit;
	}


	public void setSuit(String suit) {
		this.suit = suit;
	}
	
	public int getRank() {
		return rank;
	}


	public void setRank(int rank) {
		
		this.rank = rank;
	}

	public String getRank1() {
		return rank1;
	}


	public void setRank1(String rank1) {
		
		this.rank1 = rank1;
	}
	
	public void rankChange() {//method to print out J Q K A, but the actual value remains
	if (this.getRank()==11)
		setRank1("J");
	if (this.getRank()==12)
		setRank1("Q");
	if (this.getRank()==13)
		setRank1("K");
	if (this.getRank()==14)
		setRank1("A");
	
	}
	}
     


	

	

