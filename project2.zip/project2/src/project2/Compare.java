package project2;

public class Compare extends Deck {
	Card[] arr;

	public Compare() {
		//super.Classification();
		arr  = new Card[10];
		// TODO Auto-generated constructor stub
	}

	public void compare() {
		
		String a = "5C4c5C8SKD";
		String b = "4C5c8SJSJd";
		String split1[] = a.split("");
		String split2[] = b.split("");
		
		for(int i=0;i<10;i++) {
			arr[i]= new Card();
			
		}
		
		int i =0;
		
		for (String s:split1) {
			
			if (s.equals("2")) {
				
				arr[i].rank = 2;
			}
			else if (s.equals("3")) {
				
				arr[i].setRank(3);
			}
			else if (s.equals("4")) {
				 
				arr[i].setRank(4);
			}
			else if (s.equals("5")) {
				 
				arr[i].setRank(5);
			}
			else if (s.equals("6")) {
				
				arr[i].setRank(6);
			}
			else if (s.equals("7")) {
			
				arr[i].setRank(7);
			}
			else if (s.equals("8")) {
				
				arr[i].setRank(8);
			}
			else if (s.equals("9")) {
				
				arr[i].setRank(9);
			}
			else if (s.equals("T")||s.equals("t")) {
				
				arr[i].setRank(10);
			}
			else if (s.equals("J")||s.equals("j")) {
				
				arr[i].setRank(11);
				
			}
			else if (s.equals("Q")||s.equals("q")) {
			
				arr[i].setRank(12);
				
			}
			else if (s.equals("K")||s.equals("k")) {
				
				arr[i].setRank(13);
				
			}
			else if (s.equals("A")||s.equals("a")) {
				
				arr[i].setRank(14);
				
			}
			
			else if (s.equals("C")||s.equals("c")) {
				
				arr[i].setSuit("clubs");
				i++;
			}
			else if (s.equals("H")||s.equals("h")) {
				 
				arr[i].setSuit("hearts");
				i++;
			}
			else if (s.equals("S")||s.equals("s")) {
				 
				arr[i].setSuit("spades");
				i++;
			}
			else if (s.equals("D")||s.equals("d")) {
				 
				arr[i].setSuit("Diamonds");
				i++;
			}
		}
		
		
		 i = 5;
		
		 for (String s:split2) {
				
				if (s.equals("2")) {
					
					arr[i].rank = 2;
				}
				else if (s.equals("3")) {
					
					arr[i].setRank(3);
				}
				else if (s.equals("4")) {
					 
					arr[i].setRank(4);
				}
				else if (s.equals("5")) {
					 
					arr[i].setRank(5);
				}
				else if (s.equals("6")) {
					
					arr[i].setRank(6);
				}
				else if (s.equals("7")) {
				
					arr[i].setRank(7);
				}
				else if (s.equals("8")) {
					
					arr[i].setRank(8);
				}
                else if (s.equals("9")) {
					
					arr[i].setRank(9);
				}
				else if (s.equals("T")||s.equals("t")) {
					
					arr[i].setRank(10);
				}
				else if (s.equals("J")||s.equals("j")) {
					
					arr[i].setRank(11);
					
				}
				else if (s.equals("Q")||s.equals("q")) {
				
					arr[i].setRank(12);
					
				}
				else if (s.equals("K")||s.equals("k")) {
					
					arr[i].setRank(13);
					
				}
				else if (s.equals("A")||s.equals("a")) {
					
					arr[i].setRank(14);
					
				}
				
				else if (s.equals("C")||s.equals("c")) {
					
					arr[i].setSuit("clubs");
					i++;
				}
				else if (s.equals("H")||s.equals("h")) {
					 
					arr[i].setSuit("hearts");
					i++;
				}
				else if (s.equals("S")||s.equals("s")) {
					 
					arr[i].setSuit("spades");
					i++;
				}
				else if (s.equals("D")||s.equals("d")) {
					 
					arr[i].setSuit("Diamonds");
					i++;
				}
			}
	
		
		System.out.println(" ");
		System.out.println("Problem 4 ");
		System.out.println("We assume hand 1 is player 1 and hand 2 is player 2 ");
		System.out.println(" ");
		System.out.println("player1 in order");
		
		
		boolean fixed = false;// rank player 1's card in order, from smallest to largest
		while(fixed == false) {
		fixed = true;
	    for ( i = 0; i < 4; i++)
	    {
	        if(arr[i].rank > arr[i+1].rank)
	        {
	            Card temp=arr[i+1];
	            arr[i+1]=arr[i];
	            arr[i]=temp;
	            fixed = false;
	        }	    
		}
		}
		for ( i = 0; i < 5; i++) {
	    if (arr[i].rank > 10) {
			arr[i].rankChange();
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");
		}
		else
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
		}
		
		//player 2 in order
		System.out.println(" ");
		System.out.println("player2 in order");
		
		
		boolean fixed2 = false;
		while(fixed2 == false) {
		fixed2 = true;
	    for ( i = 5; i < 9; i++)
	    {
	        if(arr[i].rank > arr[i+1].rank)
	        {
	            Card temp=arr[i+1];
	            arr[i+1]=arr[i];
	            arr[i]=temp;
	            fixed2 = false;
	        }	    
		}
		}
		for (i = 5; i < 10; i++) {
	    if (arr[i].rank > 10) {
			arr[i].rankChange();
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank1()+" ");//print them out to check
		}
		else
			System.out.print(arr[i].getSuit()+" "+arr[i].getRank()+" ");
		}
		
		//player 1 pair judge(for 2 pairs and 1 pair)
		int pair = 0;
		int index = 0;
		for( i=0; i<4; i++) {
			if (arr[i].getRank()==arr[i+1].getRank())
			{
				pair=pair + 1;
			}
			if (arr[i].getRank()!=arr[i+1].getRank())
			{
				index=index+1;//index is for locate the largest card in hands, though it's hard to tell, you'll see it later
			}
			
		}
		
		//player 2 pair judge
		int pair1 = 0;
		int index1 = 5;
		for( i=5; i<9; i++) {
			if (arr[i].getRank()==arr[i+1].getRank())
			{
				pair1=pair1 + 1;
			}
			if (arr[i].getRank()!=arr[i+1].getRank())
			{
				index1=index1+1;
			}
		    
		}
		
		
		  
		System.out.println(" ");	
		
	int level;// level is for "who wins" part, it's easy to compare if we set a value to compare
	
	//player 1's card classification
	if (arr[0].getSuit()==arr[1].getSuit()&&//just list all the probilities out
			arr[1].getSuit()==arr[2].getSuit()&&
			arr[2].getSuit()==arr[3].getSuit()&&
			arr[3].getSuit()==arr[4].getSuit()&&
			arr[0].getRank()==arr[1].getRank()+1&&
			arr[1].getRank()==arr[2].getRank()+1&&
			arr[2].getRank()==arr[3].getRank()+1&&
			arr[3].getRank()==arr[4].getRank()+1
			
			
			
			)
		{System.out.println("player1 has a straight flush");
		level=9;
		}
	else if (arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank()||
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank())
	{System.out.println("player1 has a four of kind");
	level=8;
	}
	else if (arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()&&
			arr[3].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[3].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[4].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[1].getRank()==arr[4].getRank()||
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()&&
			arr[1].getRank()==arr[3].getRank()||
			arr[0].getRank()==arr[3].getRank()&&
			arr[4].getRank()==arr[3].getRank()&&
			arr[1].getRank()==arr[2].getRank()||
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()&&
			arr[0].getRank()==arr[4].getRank()||
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()&&
			arr[0].getRank()==arr[3].getRank()||
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank()&&
			arr[0].getRank()==arr[1].getRank()
			)
	{System.out.println("player1 has a full house");
	level=7;
	}
	else if (arr[0].getSuit()==arr[1].getSuit()&&
			arr[1].getSuit()==arr[2].getSuit()&&
			arr[2].getSuit()==arr[3].getSuit()&&
			arr[3].getSuit()==arr[4].getSuit())
	{System.out.println("player1 has a flush");
	level=6;
	}
			
	else if (arr[0].getRank()==arr[1].getRank()+1&&
			arr[1].getRank()==arr[2].getRank()+1&&
			arr[2].getRank()==arr[3].getRank()+1&&
			arr[3].getRank()==arr[4].getRank()+1)
	{System.out.println("player1 has a straight");
	level=5;
	}	
		
	else if (arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[2].getRank()||
			
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[3].getRank()||
			
			arr[0].getRank()==arr[1].getRank()&&
			arr[1].getRank()==arr[4].getRank()||
			
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
			
			arr[0].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			
			arr[0].getRank()==arr[3].getRank()&&
			arr[4].getRank()==arr[3].getRank()||
			
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[3].getRank()||
		
			arr[1].getRank()==arr[2].getRank()&&
			arr[2].getRank()==arr[4].getRank()||
			
			arr[2].getRank()==arr[3].getRank()&&
			arr[3].getRank()==arr[4].getRank())
	{System.out.println("player1 has a three of a kind");
	level=4;
	}	
		
	else if (pair == 2){//this pair is the pair we have from the loop above somewhere
				System.out.println("player1 has a 2 pairs");
				level=3;
			}
	else if (pair == 1){
		System.out.println("player1 has a pair");
		level=2;
	}
	else {
		System.out.println("player1 has only high cards");
		level = 1;//high cards
	}
	
	
	//player 2 card's classification(same way)
	int level1;
	if (arr[5].getSuit()==arr[6].getSuit()&&
			arr[6].getSuit()==arr[7].getSuit()&&
			arr[7].getSuit()==arr[8].getSuit()&&
			arr[8].getSuit()==arr[9].getSuit()&&
			arr[5].getRank()==arr[6].getRank()+1&&
			arr[6].getRank()==arr[7].getRank()+1&&
			arr[7].getRank()==arr[8].getRank()+1&&
			arr[8].getRank()==arr[9].getRank()+1)
		{System.out.println("player2 has a straight flush");
		level1=9;
		}
	else if (arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank()||
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank())
	{System.out.println("player2 has a four of kind");
	level1=8;
	}
	else if (arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()&&
			arr[8].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[8].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[9].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[6].getRank()==arr[9].getRank()||
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()&&
			arr[6].getRank()==arr[8].getRank()||
			arr[5].getRank()==arr[8].getRank()&&
			arr[9].getRank()==arr[8].getRank()&&
			arr[6].getRank()==arr[7].getRank()||
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()&&
			arr[5].getRank()==arr[9].getRank()||
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()&&
			arr[5].getRank()==arr[8].getRank()||
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank()&&
			arr[5].getRank()==arr[6].getRank()
			)
	{System.out.println("player2 has a full house");
	level1=7;
	}
	else if (arr[5].getSuit()==arr[6].getSuit()&&
			arr[6].getSuit()==arr[7].getSuit()&&
			arr[7].getSuit()==arr[8].getSuit()&&
			arr[8].getSuit()==arr[9].getSuit())
	{System.out.println("player2 has a flush");
	level1=6;
	}
			
	else if (arr[5].getRank()==arr[6].getRank()+1&&
			arr[6].getRank()==arr[7].getRank()+1&&
			arr[7].getRank()==arr[8].getRank()+1&&
			arr[8].getRank()==arr[9].getRank()+1)
	{System.out.println("player2 has a straight");
	level1=5;
	}	
		
	else if (arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[7].getRank()||
			
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[8].getRank()||
			
			arr[5].getRank()==arr[6].getRank()&&
			arr[6].getRank()==arr[9].getRank()||
			
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
			
			arr[5].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			
			arr[5].getRank()==arr[8].getRank()&&
			arr[9].getRank()==arr[8].getRank()||
			
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[8].getRank()||
		
			arr[6].getRank()==arr[7].getRank()&&
			arr[7].getRank()==arr[9].getRank()||
			
			arr[7].getRank()==arr[8].getRank()&&
			arr[8].getRank()==arr[9].getRank())
	{System.out.println("player2 has a three of a kind");
	level1=4;
	}	
		
	else if (pair1 == 2){
				System.out.println("player2 has a 2 pairs");
				level1=3;
			}
	else if (pair1 == 1){
		System.out.println("player2 has a pair");
		level1=2;
	}
	else {
		System.out.println("player2 has only high cards");
		level1 = 1;//high cards
	}	
			
			
			
			
	// "who wins" part		 
	if (level1>level) {
		System.out.println("player2 wins");
	}
	else if (level1<level) {
		System.out.println("player1 wins");
	}
	else if (level1==level&&level==9) {//level 9 since we ranked all the cards, thus the last one is the biggest one
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	else if (level1==level&&level==8) {//level 8
		if (arr[2].rank>arr[7].rank) {
			System.out.println("Player1 wins");//I used some unique method. It's hard tell. 
			}
			else if (arr[2].rank<arr[7].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[2].rank==arr[7].rank){
				if (arr[4].rank<arr[9].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[9].rank>arr[4].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
	}
	
	else if (level1==level&&level==7) {//level 7
		if (arr[2].rank>arr[7].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[2].rank<arr[7].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[2].rank==arr[7].rank){
				if (arr[3].rank<arr[8].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[3].rank>arr[8].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
				}
	
	else if (level1==level&&level==6) {//level 6 compare the largest rank
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	
	else if (level1==level&&level==5) {//level 5 compare the largest rank
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	
	else if (level1==level&&level==4) {//level 4 
		if (arr[2].rank>arr[7].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[2].rank<arr[7].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[2].rank==arr[7].rank){
				if (arr[3].rank<arr[8].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[3].rank>arr[8].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
				}
	
	
	else if (level1==level&&level==3) {//level 3
		if (arr[3].rank>arr[8].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[3].rank<arr[8].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[3].rank==arr[8].rank){
				if (arr[4].rank<arr[9].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[4].rank>arr[9].rank) {
					System.out.println("Player1 wins");
				}
				else if (arr[4].rank==arr[9].rank){
					if(arr[0].rank>arr[5].rank) {
						System.out.println("Player1 wins");	
					}
					else if(arr[0].rank<arr[5].rank) {
						System.out.println("Player2 wins");	
					}
					else if(arr[0].rank==arr[5].rank) {
						System.out.println("no winner");	
					}
				}
				}
				}
	
	else if (level1==level&&level==2) {//level 2
		if (arr[index].rank>arr[index1].rank) {
			System.out.println("Player1 wins");
			}
			else if (arr[index].rank<arr[index1].rank){
				System.out.println("Player2 wins");
				}
			else if (arr[index].rank==arr[index1].rank){
				if (arr[4].rank<arr[9].rank) {
					System.out.println("Player2 wins");
				}
				else if(arr[4].rank>arr[9].rank) {
					System.out.println("Player1 wins");
				}
				else {
					System.out.println("no winner");
				}
				}
				}
	
	else if (level1==level&&level==1) {//level 1 compare the largest rank
		if (arr[4].rank>arr[9].rank) {
		System.out.println("Player1 wins");
		}
		else if (arr[4].rank<arr[9].rank){
			System.out.println("Player2 wins");
			}
		else {
			System.out.println("no winners");
		}
	}
	
}
	
}

