package Lab1;
import java.util.ArrayList;
import java.util.Scanner;

public class isRotation {
	public static void main(String[] args){
		Scanner n = new Scanner(System.in);
		System.out.println("Please enter a word");
		String x = n.nextLine();
		System.out.println("Please enter second word");
		String y = n.nextLine();
		System.out.println(isRotation(x,y));
		}
		
		 public static boolean isRotation(String x,String y){
			 boolean result = true;
			 int l1 = x.length();
			 int l2 = y.length();
			 if (l1 != l2) {//if the two strings' lengths are not equal, then exclude directly
				 result = false;
				 System.out.println("They are not rotation");
				 return result;
			 }
			String z = x + x;//let the third string z equals two string x, z has all the possibility of the rotation
			if (z.contains(y)) {//form of x
				result = true;
			}
			else
				result = false;
			
			if (result == true) {//manage the output
	        	System.out.println("They are rotation");
	        	}
	        else
	        	System.out.println("They are not rotation");
	        
	        return result;
		 }
}
