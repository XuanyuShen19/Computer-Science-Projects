package Lab1;
import java.util.ArrayList;
import java.util.Scanner;

public class isAnagram {
	public static void main(String[] args){
	Scanner n = new Scanner(System.in);
	System.out.println("Please enter a word");
	String x = n.nextLine();
	System.out.println("Please enter second word");
	String y = n.nextLine();
	System.out.println(isAnagram(x,y));
	}
	
	 public static boolean isAnagram(String x, String y){
	        boolean result = true;
	        if(x.length()!=y.length()){
	            result = false;
	            System.out.println("They are not Anagram");
	            return result;   
	        }
	        ArrayList<String> al1 = new ArrayList<String>();
	        ArrayList<String> al2 = new ArrayList<String>();
	        int length = x.length();//the second situation that the two strings have the same length
	        for(int i = 0; i < length; i++){//make them two array lists
	        	al1.add(x.substring(i,i+1));
	        	al2.add(y.substring(i,i+1));
	        }
	        
	        int i = 0;// we run a for loop to justify if a string in al1 is also appeared in al2
	        for(i = 0; i < length; i++) {
	        	if (al2.contains(al1.get(i))) {
	        continue;// if so, we continue the loop
	        }
	        	else// if not, these two strings have the same length but different contents
	        		result = false;
	        	
	        	if (i == length) {//This means all the contents are the same in the two strings
	        		result = true;	
	        	}
	        	else 
	        		result = false;
	        }
	        
	        if (result == true) {//manage the output
	        	System.out.println("They are Anagram");
	        	}
	        else
	        	System.out.println("They are not Anagram");
	        
	        return result;
	        
	 }
}